Market Alert PC 1.0.0 — Windows 10/11 (64-bit)

- One independent desktop window with QLD / TQQQ / SOXL / QQQM tabs.
- Wide dashboard and compact messenger-style layout.
- Adjustable window opacity (35–100%) and brightness (45–120%).
- Always-on-top, tray operation, saved appearance and window settings.
- Separate data servers and portfolio records for each asset.
- Existing Kakao AdFit web advertisement.

Install `QLD-1.0.0+1-PC-Setup.exe`. Closing the window keeps it in the tray; use the tray menu or screen settings to quit completely. Press Ctrl+Shift+R to restore visibility.

The PC dashboard uses the latest regular-session prices, refreshing every five minutes. Portfolio entries are stored on this PC only. Existing account features and full strategy management are available through the integrated “전체 웹앱 열기” button. This first installer is unsigned.

한국어: 설치 파일을 실행한 뒤 바탕 화면의 Market Alert를 여세요. 우측 상단에서 작은 창 모드·항상 위 표시·밝기·투명도를 조절할 수 있습니다. 각 종목의 데이터와 보유 기록은 분리됩니다. 보유 기록은 PC에만 저장되며 모바일과 자동 동기화되지 않습니다.
