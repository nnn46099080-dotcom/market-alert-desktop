const $=id=>document.getElementById(id);
const bridge=window.desktop;
let apps={},prefs={},portfolios={},symbol='QLD',page='overview',period=126,busy=false,loadId=0;
const snapshots=new Map();
const money=v=>Number.isFinite(v)?'$'+v.toLocaleString('en-US',Math.abs(v)>=1e9?{notation:'compact',maximumFractionDigits:2}:{minimumFractionDigits:2,maximumFractionDigits:2}):'—';
const num=(v,d=1)=>Number.isFinite(v)?v.toLocaleString('en-US',{maximumFractionDigits:d}):'—';
const pct=v=>Number.isFinite(v)?`${v>0?'+':''}${v.toFixed(2)}%`:'—';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cls=v=>Number.isFinite(v)?v>=0?'positive':'negative':'muted';
const stamp=(v,time=true)=>{const d=new Date(v);return Number.isFinite(d.getTime())?d.toLocaleString('ko-KR',{month:'2-digit',day:'2-digit',...(time?{hour:'2-digit',minute:'2-digit'}:{})}):'기준 시각 없음';};
const row=(label,value,extra='')=>`<div class="row"><span class="row-label">${esc(label)}</span><strong class="${extra}">${value}</strong></div>`;
const icon=id=>`<svg><use href="#${id}-icon"/></svg>`;
const title=(name,sub='',right='')=>`<div class="card-top"><div><h3>${name}</h3>${sub?`<p class="subline">${sub}</p>`:''}</div>${right}</div>`;
function toast(text){$('toast').textContent=text;$('toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,3000);}
function current(){return snapshots.get(symbol)||{};}
function drawdownRow(){return current().drawdowns?.rows?.find(r=>r.symbol===symbol);}
function metric(id){return current().indicators?.coreIndicators?.find(v=>v.id===id);}
function holding(){return portfolios[symbol]||{shares:0,cost:0,cash:0};}
function applySettings(next){
  const changed=symbol!==next.symbol;prefs=next;symbol=next.symbol;
  document.documentElement.style.setProperty('--brightness',next.brightness);
  document.documentElement.style.setProperty('--accent',apps[symbol].color);
  document.body.classList.toggle('light',next.theme==='light');
  document.body.classList.toggle('compact-mode',next.compact);
  $('brightness').value=Math.round(next.brightness*100);$('brightness-value').value=Math.round(next.brightness*100)+'%';
  $('opacity').value=Math.round(next.opacity*100);$('opacity-value').value=Math.round(next.opacity*100)+'%';
  $('always-on-top').checked=next.alwaysOnTop;$('compact-toggle').checked=next.compact;$('light-theme').checked=next.theme==='light';$('close-to-tray').checked=next.closeToTray;
  $('pin').classList.toggle('active',next.alwaysOnTop);$('pin').setAttribute('aria-pressed',next.alwaysOnTop);
  $('compact').classList.toggle('active',next.compact);$('compact').setAttribute('aria-pressed',next.compact);
  renderTabs();if(changed){render();refresh();}else if(document.querySelector('.card'))render();
}
async function changeSettings(patch){try{applySettings(await bridge.settings(patch));}catch{toast('화면 설정을 저장하지 못했습니다.');}}
function renderTabs(){
  $('asset-tabs').innerHTML=Object.values(apps).map(a=>`<button class="asset-tab ${a.symbol===symbol?'active':''}" data-symbol="${a.symbol}" aria-pressed="${a.symbol===symbol}" style="--tab-color:${a.color}"><span class="asset-dot"></span>${a.symbol}</button>`).join('');
}
function summary(){
  const data=current(),q=data.chart,d=drawdownRow(),p=holding();const value=q?p.shares*q.price+p.cash:null;
  return `<div class="summary-grid"><section class="card quote-card"><div class="card-label"><span>${symbol} 현재가</span><span class="badge accent">${esc(apps[symbol].tag)}</span></div><div class="price">${money(q?.price)}<small>USD</small></div><div class="quote-detail"><span class="change ${cls(q?.change)}">${pct(q?.change)}</span> <span class="tiny muted">정규장 전일 대비</span><div class="metric-foot" style="margin-top:7px">${q?stamp(q.asOf)+' 정규장 기준':'가격 데이터 대기 중'}</div></div></section>
  <section class="card"><div class="card-label">고점 대비 하락률<span class="badge">서버 기준</span></div><div class="metric-number ${cls(d?.drawdown)}">${pct(d?.drawdown)}</div><div class="metric-foot">기준 고점 ${money(d?.high)}</div></section>
  <section class="card"><div class="card-label">내 자산 평가액<span class="badge">이 PC</span></div><div class="metric-number">${p.shares||p.cash?money(value):'—'}</div><div class="metric-foot">${p.shares||p.cash?`${symbol} ${num(p.shares,6)}주 · 현금 포함`:'보유 정보를 입력해 시작하세요'}</div></section></div>`;
}
function strategyCard(detailed=false){
  const a=apps[symbol],s=current().strategy,d=drawdownRow();
  const reached=Number.isFinite(s?.reachedMaxZone)?s.reachedMaxZone:null;
  const active=s?.initialized&&s.active===true;
  const status=!s?'전략 상태 확인 중':!s.initialized?'전략 초기화 대기':active?'진행 중인 전략':'기본 비중 유지';
  return `<section class="card">${title('투자 전략',`${symbol} 전용 전략 상태`,`<span class="badge accent">${esc(status)}</span>`)}<div class="strategy-hero"><b>${active?`최대 도달 구간 −${reached}%`:s?'나의 원칙대로, 차분하게':'전략 데이터를 기다리고 있습니다'}</b><p>${active?'서버에 기록된 현재 주기의 상태입니다. 가격이 회복되어도 도달 기록은 유지될 수 있습니다.':s?`기본 목표 비중은 ${symbol} ${a.stock}% · 현금 ${a.cash}%입니다.`:'연결 후 종목별 실제 상태를 표시합니다.'}</p></div><div class="strategy-steps">${a.zones.map(z=>`<span class="step ${reached!==null&&reached>=z?'reached':''}" title="−${z}%"></span>`).join('')}</div>${row('기준 하락률',`<span class="${cls(d?.drawdown)}">${pct(d?.drawdown)}</span>`)}${row('현재 전략 구간',Number.isFinite(s?.currentZone)?s.currentZone===0?'기본 구간':`−${s.currentZone}%`:'—')}${row('전략 기준일',esc(s?.asOfNyDate||'—'))}<div class="allocation"><span style="width:${a.stock}%"></span></div><div class="allocation-labels"><span>${symbol} ${a.stock}%</span><span>현금 ${a.cash}%</span></div>${detailed?`<div class="recovery">${esc(s?.basis||'전략 기준 정보 없음')}<br>구간별 주문·전환·매수 완료 기록은 기존 전체 웹앱에서 확인하고 관리할 수 있습니다.</div>`:''}<button class="button secondary full-width-button" data-action="web">전체 전략 · 기존 웹앱 ${icon('external')}</button></section>`;
}
function portfolioCard(detailed=false){
  const p=holding(),q=current().chart,value=q?p.shares*q.price:null,total=value===null?null:value+p.cash;
  const profit=value===null?null:value-p.shares*p.cost,ratio=total>0?value/total*100:0;
  const has=p.shares>0||p.cash>0;
  return `<section class="card">${title('내 포트폴리오',`${symbol} · 종목별 독립 저장`,`<button class="button secondary" data-action="edit">${has?'편집':'입력'}</button>`)}${has?`<div class="mini-portfolio"><div class="donut" style="--share:${ratio}%"><span>${num(ratio,0)}<small>%</small></span></div><div><div class="tiny muted">총 평가액 · USD</div><div class="portfolio-total">${money(total)}</div><span class="tiny ${cls(profit)}">평가손익 ${money(profit)}</span></div></div>${row('보유 수량',`${num(p.shares,6)}주`)}${row('보유 현금',money(p.cash))}${detailed?row('평균 매수가',money(p.cost))+row('주식 평가액',money(value))+row('누적 매입금',money(p.shares*p.cost)):''}`:`<div class="empty-portfolio">보유 수량과 평균 매수가를 입력하면<br>자산 비중과 평가손익을 확인할 수 있어요.</div><div class="allocation"><span style="width:0"></span></div><div class="allocation-labels"><span>${symbol}</span><span>현금</span></div><button class="button primary full-width-button" data-action="edit">+ 내 보유 정보 입력</button>`}</section>`;
}
function chartCard(){
 const q=current().chart;
 return `<section class="card chart-card">${title(`${symbol} 가격 흐름`,esc(apps[symbol].name),`<div class="periods" aria-label="차트 기간">${[[21,'1M'],[63,'3M'],[126,'6M'],[252,'1Y'],[0,'전체']].map(([n,t])=>`<button class="period ${period===n?'active':''}" data-period="${n}" aria-pressed="${period===n}">${t}</button>`).join('')}</div>`)}<div class="chart-stat"><span>${symbol} 종가</span><span>20일 평균</span><span>200일 평균</span></div>${q?'<div class="chart-wrap" id="chart-wrap" tabindex="0" aria-label="가격 차트. 좌우 방향키로 날짜별 가격 탐색"></div>':'<div class="chart-empty">가격 이력을 불러오고 있습니다.</div>'}<div class="chart-foot"><span>일별 종가 · 수정 전 가격 기준</span><span>${q?stamp(q.asOf)+' 기준':'연결 대기'}</span></div></section>`;
}
function marketCard(){
 const f=metric('fearGreed'),v=metric('vix'),t=metric('tenYearYield');
 const label=!Number.isFinite(f?.value)?'확인 중':f.value<25?'극도의 공포':f.value<45?'공포':f.value<55?'중립':f.value<75?'탐욕':'극도의 탐욕';
 return `<section class="card market-card">${title('시장의 온도','공포탐욕 · 변동성 · 금리')}<div class="market-strip"><div class="mini-metric"><span class="tiny muted">공포탐욕지수</span><b>${num(f?.value,0)} <small>/ 100</small></b><span class="tiny" style="color:var(--accent)">${label}</span></div><div class="mini-metric"><span class="tiny muted">VIX</span><b>${num(v?.value,2)}</b><small>시장 변동성</small></div><div class="mini-metric"><span class="tiny muted">미국 10년물</span><b>${num(t?.value,2)}<small>%</small></b><small>국채 수익률</small></div></div><div class="fear-track">${Number.isFinite(f?.value)?`<i style="--score:${Math.min(100,Math.max(0,f.value))}%"></i>`:''}</div><p class="tiny muted">지표 기준 ${stamp(current().indicators?.asOf)}</p></section>`;
}
function marketPage(){
 const data=current(),names={cpi:'소비자물가 CPI',corePce:'근원 PCE',ppi:'생산자물가 PPI',unemployment:'실업률',ismManufacturingPmi:'ISM 제조업 PMI',fedFundsProbability:'금리 동결 확률',treasury30:'미국 30년물',m2YoY:'M2 증가율',highYieldSpread:'하이일드 스프레드',credit:'HYG / IEF'};
 const rows=(data.indicators?.indicators||[]).filter(i=>names[i.id]);
 const dd=(data.drawdowns?.rows||[]).filter(r=>['QQQ','QLD','TQQQ','SOXL','SOXX','QQQM','^GSPC','^NDX'].includes(r.symbol));
 return `<div class="page-grid"><div class="wide">${marketCard()}</div><section class="card wide">${title('주요 경제 지표','지표별 발표일과 단위가 다릅니다.')}<div class="table-wrap"><table class="table"><thead><tr><th>지표</th><th>값</th><th>기준일</th><th>다음 발표</th></tr></thead><tbody>${rows.length?rows.map(i=>`<tr><td>${esc(names[i.id])}</td><td>${num(i.value,2)} <span class="tiny muted">${esc(i.unit)}</span></td><td>${esc(i.date)}</td><td>${esc(i.nextReleaseDate||'—')}</td></tr>`).join(''):'<tr><td colspan="4">지표 데이터를 불러오는 중입니다.</td></tr>'}</tbody></table></div></section><section class="card wide">${title('종목별 고점 대비 하락률',`서버 기준 · ${stamp(data.drawdowns?.asOf)}`)}<div class="table-wrap"><table class="table"><thead><tr><th>종목</th><th>기준 가격</th><th>기준 고점</th><th>하락률</th></tr></thead><tbody>${dd.map(r=>`<tr><td>${esc(r.symbol)}</td><td>${money(r.close)}</td><td>${money(r.high)}</td><td class="${cls(r.drawdown)}">${pct(r.drawdown)}</td></tr>`).join('')}</tbody></table></div></section></div>`;
}
function strategyPage(){
 const a=apps[symbol],d=drawdownRow();
 return `<div class="page-grid">${strategyCard(true)}<section class="card">${title('전략 구간 참고','고점 대비 목표 가격 · 주문 신호가 아닙니다.')}<div class="table-wrap"><table class="table"><thead><tr><th>하락 구간</th><th>참고 가격</th><th>현재 주기 도달</th></tr></thead><tbody>${a.zones.map(z=>`<tr><td>−${z}%</td><td>${money(d?.high?d.high*(1-z/100):null)}</td><td>${Number.isFinite(current().strategy?.reachedMaxZone)?current().strategy.reachedMaxZone>=z?'도달 기록 있음':'—':'확인 중'}</td></tr>`).join('')}</tbody></table></div><div class="recovery">이 표는 서버가 제공하는 고점으로 계산한 참고 가격입니다. 실제 전략의 장중 고점·주기·실행 조건은 전체 웹앱의 종목별 전략을 따릅니다.</div></section><div class="wide">${chartCard()}</div></div>`;
}
function render(){
 const headings={overview:['한눈에 보는 나의 투자','시장의 흐름을 확인하고, 나만의 원칙을 지켜보세요.'],strategy:['원칙을 지키는 투자 전략',`${symbol}의 실제 전략 상태와 구간을 확인하세요.`],portfolio:['나의 투자, 나의 기록','종목별 보유 정보를 이 PC에서 관리하세요.'],market:['시장 흐름을 읽는 지표','주요 경제 지표와 종목별 하락률을 함께 확인하세요.']};
 $('page-title').textContent=headings[page][0];$('page-subtitle').textContent=headings[page][1];
 document.querySelectorAll('#side-nav button').forEach(b=>{b.classList.toggle('selected',b.dataset.page===page);b.setAttribute('aria-current',b.dataset.page===page?'page':'false');});
 const nav=`<nav class="mobile-nav" aria-label="메뉴">${[['overview','대시보드'],['strategy','전략'],['portfolio','내 자산'],['market','시장 지표']].map(([p,t])=>`<button data-page="${p}" class="${p===page?'selected':''}">${t}</button>`).join('')}<button data-action="web">웹앱 ↗</button></nav>`;
 const body=page==='overview'?summary()+`<div class="main-grid"><div class="main-column">${chartCard()}${marketCard()}</div><div class="right-column">${strategyCard()}${portfolioCard()}</div></div>`:page==='strategy'?strategyPage():page==='portfolio'?`<div class="page-grid">${portfolioCard(true)}<section class="card">${title('종목별 보유 현황','다른 탭의 정보는 서로 섞이지 않습니다.')}<div class="table-wrap"><table class="table"><thead><tr><th>종목</th><th>보유 수량</th><th>현금</th></tr></thead><tbody>${Object.keys(apps).map(s=>`<tr><td>${s}</td><td>${num(portfolios[s]?.shares||0,6)}주</td><td>${money(portfolios[s]?.cash||0)}</td></tr>`).join('')}</tbody></table></div><div class="recovery">PC 보유 기록은 모바일·웹 계정과 자동 동기화되지 않습니다. 기존 계정의 보유 정보와 모든 기능은 ‘전체 웹앱 열기’에서 이용할 수 있습니다.</div></section></div>`:marketPage();
 $('content').innerHTML=nav+body;updateStatus();renderChart();
}
function movingAverage(points,n){let total=0;return points.map((p,i)=>{total+=p.v;if(i>=n)total-=points[i-n].v;return i>=n-1?total/n:null;});}
function renderChart(){
 const wrap=$('chart-wrap'),q=current().chart;if(!wrap||!q)return;
 const all=q.points,offset=period?Math.max(0,all.length-period):0,points=all.slice(offset),ma20=movingAverage(all,20).slice(offset),ma200=movingAverage(all,200).slice(offset);
 const w=700,h=250,left=5,right=58,top=20,bottom=28,pw=w-left-right,ph=h-top-bottom;
 const nums=[...points.map(p=>p.v),...ma20,...ma200].filter(Number.isFinite),lo=Math.min(...nums)*.97,hi=Math.max(...nums)*1.03,range=hi-lo||1;
 const x=i=>left+(points.length>1?i/(points.length-1):.5)*pw,y=v=>top+(hi-v)/range*ph;
 const path=values=>values.map((v,i)=>Number.isFinite(v)?`${i===0||!Number.isFinite(values[i-1])?'M':'L'}${x(i).toFixed(2)},${y(v).toFixed(2)}`:'').join(' ');
 const line=path(points.map(p=>p.v));
 const grids=Array.from({length:5},(_,i)=>{const v=lo+i*range/4,yy=y(v);return `<line class="gridline" x1="${left}" x2="${w-right}" y1="${yy}" y2="${yy}"/><text x="${w-right+12}" y="${yy+4}">${num(v,2)}</text>`;}).join('');
 const ticks=[0,Math.floor((points.length-1)/3),Math.floor(2*(points.length-1)/3),points.length-1].map(i=>`<text x="${x(i)}" y="${h-4}" text-anchor="${i===0?'start':'middle'}">${esc(stamp(points[i].t,false))}</text>`).join('');
 wrap.innerHTML=`<svg class="chart-svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" role="img" aria-label="${symbol}의 일별 가격, 20일 및 200일 이동평균"><defs><linearGradient id="chart-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${apps[symbol].color}" stop-opacity=".2"/><stop offset="100%" stop-color="${apps[symbol].color}" stop-opacity="0"/></linearGradient></defs>${grids}<path d="${line} L${x(points.length-1)},${h-bottom} L${x(0)},${h-bottom} Z" fill="url(#chart-fill)"/><path d="${path(ma200)}" fill="none" stroke="#73bbdd" stroke-width="1.4" opacity=".7"/><path d="${path(ma20)}" fill="none" stroke="#e7c286" stroke-width="1.4" opacity=".8"/><path d="${line}" fill="none" stroke="${apps[symbol].color}" stroke-width="2.3" stroke-linejoin="round" stroke-linecap="round"/>${ticks}<line id="crosshair" x1="0" x2="0" y1="${top}" y2="${h-bottom}" stroke="${apps[symbol].color}" stroke-dasharray="3 4" opacity="0"/></svg><div class="chart-tooltip" hidden></div>`;
 let index=points.length-1;
 function inspect(i){index=Math.max(0,Math.min(points.length-1,i));const p=points[index],tt=wrap.querySelector('.chart-tooltip'),cross=$('crosshair');tt.hidden=false;tt.innerHTML=`${new Date(p.t).toLocaleDateString('ko-KR')}<b>${money(p.v)}</b>`;tt.style.left=Math.min(wrap.clientWidth-140,Math.max(0,x(index)/w*wrap.clientWidth-60))+'px';cross.setAttribute('x1',x(index));cross.setAttribute('x2',x(index));cross.setAttribute('opacity','.6');}
 wrap.onpointermove=e=>{const r=wrap.getBoundingClientRect();inspect(Math.round(((e.clientX-r.left)/r.width*w-left)/pw*(points.length-1)));};
 wrap.onpointerleave=()=>{wrap.querySelector('.chart-tooltip').hidden=true;$('crosshair').setAttribute('opacity','0');};
 wrap.onkeydown=e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();inspect(index+(e.key==='ArrowLeft'?-1:1));}};
}
function updateStatus(){
 const d=current(),errors=Object.keys(d.errors||{}),q=d.chart;
 $('connection').classList.toggle('loading',busy);
 const old=q&&Date.now()-q.asOf>36*3600000;
 $('connection-text').textContent=busy?'데이터 확인 중…':d.fetchedAt?`${errors.length?'일부 데이터 연결 지연 · ':''}${symbol} · ${stamp(d.fetchedAt)} 확인 · 5분마다 갱신${old?' · 최근 거래일 가격':''}`:'데이터 연결 대기';
 $('refresh').disabled=busy;
 const names={chart:'가격',strategy:'전략',drawdowns:'하락률',indicators:'시장 지표'};
 $('error-banner').hidden=!errors.length;
 $('error-banner').textContent=errors.length?`${errors.map(k=>names[k]).join(' · ')} 데이터를 갱신하지 못했습니다. 이전에 받은 값이 있으면 그대로 표시합니다. 연결을 확인하고 다시 시도하세요.`:'';
}
async function refresh(){
 const id=++loadId,target=symbol;busy=true;updateStatus();
 try{const next=await bridge.market(target);const old=snapshots.get(target)||{};snapshots.set(target,{...old,...next});if(id!==loadId||target!==symbol)return;busy=false;render();}
 catch{if(id!==loadId)return;busy=false;const old=current();snapshots.set(symbol,{...old,errors:{chart:'연결 실패',strategy:'연결 실패',drawdowns:'연결 실패',indicators:'연결 실패'}});render();}
}
function openPortfolio(){const p=holding();$('portfolio-symbol').textContent=symbol;$('shares').value=p.shares;$('cost').value=p.cost;$('cash').value=p.cash;$('portfolio-dialog').dataset.symbol=symbol;$('portfolio-dialog').showModal();}
function actions(event){const b=event.target.closest('button');if(!b)return;if(b.dataset.symbol)changeSettings({symbol:b.dataset.symbol});if(b.dataset.page){page=b.dataset.page;render();$('main').scrollTo(0,0);}if(b.dataset.period!==undefined){period=Number(b.dataset.period);render();}if(b.dataset.action==='edit')openPortfolio();if(b.dataset.action==='web')bridge.webApp(symbol);}
document.addEventListener('click',actions);
$('refresh').onclick=refresh;$('web-app').onclick=()=>bridge.webApp(symbol);$('homepage').onclick=()=>bridge.homepage();
$('settings-open').onclick=()=>$('settings-dialog').showModal();
document.querySelectorAll('.dialog-close').forEach(b=>b.onclick=()=>b.closest('dialog').close());
$('pin').onclick=()=>changeSettings({alwaysOnTop:!prefs.alwaysOnTop});$('compact').onclick=()=>changeSettings({compact:!prefs.compact});
$('brightness').oninput=e=>changeSettings({brightness:Number(e.target.value)/100});$('opacity').oninput=e=>changeSettings({opacity:Number(e.target.value)/100});
$('always-on-top').onchange=e=>changeSettings({alwaysOnTop:e.target.checked});$('compact-toggle').onchange=e=>changeSettings({compact:e.target.checked});$('light-theme').onchange=e=>changeSettings({theme:e.target.checked?'light':'dark'});$('close-to-tray').onchange=e=>changeSettings({closeToTray:e.target.checked});
$('reset-appearance').onclick=()=>changeSettings({opacity:1,brightness:1});$('quit').onclick=()=>bridge.window('quit');
$('portfolio-form').onsubmit=async e=>{e.preventDefault();const target=$('portfolio-dialog').dataset.symbol;try{portfolios[target]=await bridge.portfolio(target,{shares:Number($('shares').value),cost:Number($('cost').value),cash:Number($('cash').value)});$('portfolio-dialog').close();render();toast(target+' 보유 정보를 저장했습니다.');}catch{toast('저장하지 못했습니다. 다시 시도하세요.');}};
async function init(){
 try{const initial=await bridge.bootstrap();apps=initial.apps;portfolios=initial.portfolios;prefs=initial.settings;symbol=prefs.symbol;$('version').textContent=initial.version;
 $('today').textContent=new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'}).toUpperCase();
 applySettings(prefs);bridge.onSettings(applySettings);render();refresh();setInterval(refresh,300000);
 }catch(e){$('connection-text').textContent='PC 앱을 초기화하지 못했습니다.';$('error-banner').hidden=false;$('error-banner').textContent='앱을 완전히 종료한 뒤 다시 실행해 주세요.';console.error(e);}
}
init();
