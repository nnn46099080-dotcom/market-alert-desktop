const fs=require('node:fs'),path=require('node:path');
const p=path.resolve(__dirname,'../index.html');
let html=fs.readFileSync(p,'utf8');
if(!html.includes('qld-market-alert-pc.web.app')){
 html=html.replace('<a class="btn" href="#features"','<a class="btn" href="https://qld-market-alert-pc.web.app/#download" data-en="Windows PC" data-ko="Windows PC 버전"></a><a class="btn" href="#features"');
 html=html.replace(/<section class="section" id="download">[\s\S]*?<\/section>/,section=>section.replace('</div></div></section>','<a class="btn" href="https://qld-market-alert-pc.web.app/#download" data-en="Download Windows PC App" data-ko="Windows PC 버전 다운로드"></a></div></div></section>'));
 html=html.replace('QLD DIP ALERT supports Android and iPhone web app access.','QLD DIP ALERT supports Android, iPhone web access, and the Windows PC workspace.').replace('QLD DIP ALERT는 Android 앱과 iPhone 웹앱을 지원합니다.','QLD DIP ALERT는 Android 앱, iPhone 웹앱, Windows PC 통합 앱을 지원합니다.');
 if((html.match(/qld-market-alert-pc.web.app/g)||[]).length!==2)throw Error('Expected two PC download links');
 fs.writeFileSync(p,html);
}
console.log('Homepage PC download links prepared.');
