# Market Alert for Windows

QLD, TQQQ, SOXL and QQQM in one independently installed Windows application.

## Use

- Windows 10/11 64-bit. Open `Market Alert` from the desktop or Start menu.
- Switch assets in the four top tabs. The navigation adapts to the window width.
- Use the top-right pin, compact window, and screen settings buttons.
- Screen brightness: 45–120%. Window opacity: 35–100%.
- `Ctrl+Shift+R` restores brightness and opacity to 100%. The tray menu also provides recovery.
- Closing the window keeps it in the tray by default. Double-click the tray icon to reopen, or use `완전히 종료` to quit. Close-to-tray is configurable.
- Price data uses the existing asset-specific public Workers. Data refreshes every five minutes. The dashboard shows the last regular-session price and its actual timestamp, rather than pretending a weekend price is live.
- Strategy state comes from the asset's own server. The PC strategy table is informational; full strategy execution history and all existing app features remain available through `전체 웹앱 열기`.
- Portfolio quantities, average costs and cash are local PC records, separate per symbol. They do not sync with mobile accounts.
- Advertisement: existing Kakao AdFit web unit, loaded in an isolated HTTPS frame. Delivery depends on the ad service's site review, availability and client environment.
- This initial release is not code signed. Windows may display an unrecognized-publisher notice.

## Development

Node.js 22 or newer:

```text
npm ci
npm test
npm start
npm run dist
```

The NSIS installer is written to `outputs/QLD/desktop/QLD-1.0.0+1-PC-Setup.exe` relative to the original MarketAlert workspace. This is a separate desktop launcher and does not build or modify the four Flutter apps.

The distribution uses its own Firebase Hosting site, `qld-market-alert-pc`. Never replace an existing mobile/web app site when publishing desktop download pages.

Only desktop sources and assets belong in this directory. Never copy the parent Flutter source, signing files, local settings, credentials or private data into the public homepage repository.
