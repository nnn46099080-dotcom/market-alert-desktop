const {test}=require('node:test');const assert=require('node:assert/strict');
const {APPS,settings,chart,holding}=require('../core.cjs');
test('four tabs retain separate API and web app mapping without exposing deployment accounts',()=>{
 assert.equal(Object.keys(APPS).length,4);
 assert.equal(APPS.QLD.web,'https://qld-a-m.web.app');
 assert.equal(APPS.TQQQ.web,'https://tqqq-cc7e2.web.app');
 assert.equal(APPS.SOXL.web,'https://soxl-dip-alert-9080.web.app');
 assert.equal(APPS.QQQM.web,'https://qqqm-dip-alert-nnn46099080.web.app');
 for(const a of Object.values(APPS))assert.equal(a.account,undefined);
 assert.equal(new Set(Object.values(APPS).map(a=>a.api)).size,4);assert.equal(new Set(Object.values(APPS).map(a=>a.web)).size,4);
});
test('appearance clamps opacity and brightness to recoverable limits',()=>{assert.equal(settings({opacity:0}).opacity,.35);assert.equal(settings({opacity:Infinity}).opacity,1);assert.equal(settings({brightness:99}).brightness,1.2);assert.equal(settings({brightness:-1}).brightness,.45);assert.equal(settings({symbol:'UNKNOWN'}).symbol,'QLD');assert.equal(settings({alwaysOnTop:'true'}).alwaysOnTop,false);});
test('chart rejects another asset and never uses long-range chartPreviousClose as yesterday',()=>{
 const raw={chart:{result:[{meta:{symbol:'SOXL',regularMarketPrice:22,regularMarketTime:123,chartPreviousClose:1},timestamp:[1,2,3],indicators:{quote:[{close:[19,null,20]}]}}]}};
 assert.throws(()=>chart(raw,'QLD'));const c=chart(raw,'SOXL');assert.equal(c.points.length,2);assert.ok(Math.abs(c.change-(22/19-1)*100)<1e-9);
 raw.chart.result[0].meta.regularMarketChangePercent=-.5;assert.equal(chart(raw,'SOXL').change,-.5);
});
test('invalid persisted financial values cannot create NaN or negative portfolios',()=>{assert.deepEqual(holding({shares:-1,cost:Infinity,cash:'10'}),{shares:0,cost:0,cash:0});assert.equal(holding({shares:1.25}).shares,1.25);});
