// Integration QA runs against the real Electron renderer with its own empty profile.
const {app,BrowserWindow}=require('electron');
const path=require('node:path'),fs=require('node:fs'),assert=require('node:assert/strict');
const out=path.resolve(__dirname,'../../../outputs/QLD/desktop/qa');
fs.mkdirSync(out,{recursive:true});app.setPath('userData',path.join(out,'profile-'+Date.now()));
require('../main.cjs');
const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function until(fn,ms=30000){const start=Date.now();while(Date.now()-start<ms){if(await fn())return;await delay(200);}throw new Error('QA wait timed out');}
app.whenReady().then(async()=>{
 const errors=[],checks=[];
 try{
  await until(()=>BrowserWindow.getAllWindows().length);
  const w=BrowserWindow.getAllWindows()[0];
  w.webContents.on('console-message',event=>{if(event.level==='error'&&!/404|ERR_|AdFit|adfit/.test(event.message))errors.push(event.message);});
  await until(()=>w.webContents.executeJavaScript('!!window.desktop && !!document.querySelector(".asset-tab")').catch(()=>false));
  const run=js=>w.webContents.executeJavaScript(js);
  assert.equal(await run('document.querySelectorAll(".asset-tab").length'),4);checks.push('four asset tabs');
  for(const symbol of ['QLD','TQQQ','SOXL','QQQM']){
   await run(`window.desktop.settings({symbol:${JSON.stringify(symbol)}})`);
   await until(()=>run('document.querySelector(".connection:not(.loading)")!==null'),60000);
   const result=await run(`({active:document.querySelector('.asset-tab.active').textContent,quote:document.querySelector('.quote-card .price')?.textContent,error:document.querySelector('#error-banner').hidden,overflow:document.documentElement.scrollWidth>innerWidth})`);
   assert.equal(result.active,symbol);assert.ok(!result.quote.includes('—'),symbol+' live chart failed');assert.equal(result.overflow,false);checks.push({symbol,...result});
  }
  await run('window.desktop.settings({symbol:"QLD"})');await until(()=>run('!document.querySelector(".connection.loading")'));
  w.setSize(1380,1000);await delay(500);fs.writeFileSync(path.join(out,'QLD-desktop-wide.png'),(await w.webContents.capturePage()).toPNG());
  for(const width of [1024,760,460,420]){w.setSize(width,790);await delay(250);assert.equal(await run('document.documentElement.scrollWidth>innerWidth'),false);const bad=await run(`[...document.querySelectorAll('.card')].filter(e=>e.scrollWidth>e.clientWidth+2).map(e=>e.className)`);assert.deepEqual(bad,[]);checks.push('no card overflow at '+width);}
  await run('window.desktop.settings({compact:true,opacity:.6,brightness:.7,alwaysOnTop:true})');assert.ok(Math.abs(w.getOpacity()-.6)<.02);assert.equal(w.isAlwaysOnTop(),true);assert.equal(await run('getComputedStyle(document.documentElement).getPropertyValue("--brightness").trim()'),'.7'.replace(/^\./,'0.'));checks.push('native window opacity + brightness + pin + compact');
  await run('window.desktop.settings({opacity:1,brightness:1,alwaysOnTop:false})');await delay(300);fs.writeFileSync(path.join(out,'QLD-desktop-compact.png'),(await w.webContents.capturePage()).toPNG());
  await run('document.querySelector("#settings-open").click()');await delay(200);fs.writeFileSync(path.join(out,'QLD-desktop-settings.png'),(await w.webContents.capturePage()).toPNG());await run('document.querySelector("#settings-dialog").close()');
  await run('window.desktop.portfolio("QLD",{shares:3,cost:80,cash:500})');await run('window.desktop.portfolio("TQQQ",{shares:7,cost:60,cash:200})');
  const data=await run('window.desktop.bootstrap()');assert.equal(data.portfolios.QLD.shares,3);assert.equal(data.portfolios.TQQQ.shares,7);assert.equal(data.portfolios.SOXL,undefined);checks.push('portfolio isolation and persistence');
  for(const p of ['strategy','portfolio','market']){await run(`document.querySelector('[data-page="${p}"]').click()`);await delay(100);assert.equal(await run('document.documentElement.scrollWidth>innerWidth'),false);checks.push(p+' compact layout');}
  await run('window.desktop.settings({compact:false,opacity:1,brightness:1,alwaysOnTop:false})');
  w.close();assert.equal(w.isDestroyed(),false);assert.equal(w.isVisible(),false);checks.push('close keeps app in tray');
  if(errors.length)throw new Error(errors.join('\n'));
  fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({passed:true,checks},null,2));console.log(JSON.stringify({passed:true,checks}));app.exit(0);
 }catch(e){console.error(e);fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({passed:false,error:e.message,checks,errors},null,2));app.exit(1);}
});
